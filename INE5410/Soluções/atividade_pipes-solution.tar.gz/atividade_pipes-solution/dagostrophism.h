#ifndef DAGOSTROPHISM_H_
#define DAGOSTROPHISM_H_

int is_dagostrophic();

#endif /*DAGOSTROPHISM_H_*/
