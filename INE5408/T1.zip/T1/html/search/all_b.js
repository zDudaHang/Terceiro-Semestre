var searchData=
[
  ['_7elinkedqueue',['~LinkedQueue',['../classstructures_1_1LinkedQueue.html#ad3f70a9465ecbf8868ad9206e2b01711',1,'structures::LinkedQueue']]],
  ['_7elinkedstack',['~LinkedStack',['../classstructures_1_1LinkedStack.html#aae17566eb103c92eb22be2e779286f2f',1,'structures::LinkedStack']]]
];
