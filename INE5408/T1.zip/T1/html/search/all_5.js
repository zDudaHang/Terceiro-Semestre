var searchData=
[
  ['getcolumn',['getColumn',['../classstructures_1_1ElementToSee.html#a3a79c7c2d59cea83ace1c626574326a4',1,'structures::ElementToSee']]],
  ['getline',['getLine',['../classstructures_1_1ElementToSee.html#afcdb04e03dc9150c04c8647119d7dbde',1,'structures::ElementToSee']]],
  ['getmatrixheights',['getMatrixHeights',['../main_8cpp.html#a883198d3926ad62b7dedc590e66a3197',1,'main.cpp']]],
  ['getmatrixwidths',['getMatrixWidths',['../main_8cpp.html#a93f0aeb2b15fbc361118a08869d71c80',1,'main.cpp']]],
  ['gettingimagenames',['gettingImageNames',['../main_8cpp.html#a0fad19e1d327b8b2a573dd7d77aa505c',1,'main.cpp']]],
  ['getxmlmatrix',['getXMLMatrix',['../main_8cpp.html#a5641cbfa268d04ca53d7455517a65f78',1,'main.cpp']]],
  ['getxmltext',['getXMLText',['../main_8cpp.html#ad7ad8d67f833642b881180a9ba81e15f',1,'main.cpp']]]
];
