var searchData=
[
  ['linkedqueue',['LinkedQueue',['../classstructures_1_1LinkedQueue.html',1,'structures']]],
  ['linkedstack',['LinkedStack',['../classstructures_1_1LinkedStack.html',1,'structures']]]
];
