var searchData=
[
  ['linked_5fqueue_2eh',['linked_queue.h',['../linked__queue_8h.html',1,'']]],
  ['linked_5fstack_2eh',['linked_stack.h',['../linked__stack_8h.html',1,'']]]
];
