var searchData=
[
  ['dequeue',['dequeue',['../classstructures_1_1LinkedQueue.html#af6037408a07637554b8a8be7201a756d',1,'structures::LinkedQueue']]]
];
