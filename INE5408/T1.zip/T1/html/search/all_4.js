var searchData=
[
  ['findthebeginofxml',['findTheBeginOfXML',['../main_8cpp.html#aab70c8c83c6f2052ae314fca46147f1b',1,'main.cpp']]],
  ['findtheendofxml',['findTheEndOfXML',['../main_8cpp.html#ab00b42e16b61b25a9ed03a75fad135b4',1,'main.cpp']]],
  ['front',['front',['../classstructures_1_1LinkedQueue.html#a904219098f1f6b3aa229a8ea0f929b64',1,'structures::LinkedQueue']]]
];
