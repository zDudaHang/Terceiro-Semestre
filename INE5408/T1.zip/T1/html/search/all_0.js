var searchData=
[
  ['back',['back',['../classstructures_1_1LinkedQueue.html#ac69ee50f58e8501f7eaddec5b474a87c',1,'structures::LinkedQueue']]]
];
